# @Time : 2021/10/18 15:55
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : IdeaDemo001.py
import numpy as np
from sklearn.cluster import KMeans

from MILFrame.MILTool import MILTool


class IdeaDemo001:
    def __init__(self, para_bags, train_bags, test_bags):
        self.bags = para_bags
        self.train_bags = train_bags
        self.test_bags = test_bags
        self.ins = self.__get_positive_instance()
        self.center_cluster = self.__cluster_kmeans()
        self.num_att = self.bags[0, 0].shape[1] - 1
        self.train_instance = self.__single_instance()
        self.test_instance = self.__test_single_instance()

    def __single_instance(self):
        new_bag = []
        for i in range(self.train_bags.shape[0]):
            single_bag_instance = np.zeros(self.num_att * 3).astype('float64')
            for ins_to_bag in self.train_bags[i, 0][:, :-1]:
                ins_center_dis = np.zeros(3).astype('float32')
                for i_center in range(3):
                    ins_center_dis[i_center] = 1 / (np.linalg.norm(ins_to_bag - self.center_cluster[i_center]))
                ins_center_dis = self.__max_min_normalization(ins_center_dis)
                if self.train_bags[i, -1] == 1:
                    new_ins_to_bag_one = self.center_cluster[0] + (self.center_cluster[0] * ins_center_dis[0]) / \
                                         self.train_bags[i, 0].shape[0]
                    new_ins_to_bag_two = self.center_cluster[1] - (self.center_cluster[1] * ins_center_dis[1]) / \
                                         self.train_bags[i, 0].shape[0]
                    new_ins_to_bag_three = (self.center_cluster[1] + self.center_cluster[2] * ins_center_dis[2]) / 2
                else:
                    new_ins_to_bag_one = self.center_cluster[0] - (self.center_cluster[0] * ins_center_dis[0]) / \
                                         self.train_bags[i, 0].shape[0]
                    new_ins_to_bag_two = self.center_cluster[1] + (self.center_cluster[1] * ins_center_dis[1]) / \
                                         self.train_bags[i, 0].shape[0]
                    new_ins_to_bag_three = (self.center_cluster[1] + self.center_cluster[2] * ins_center_dis[2]) / 2

                # print(type(new_ins_to_bag_two))
                new_ins_to_bag = np.hstack((new_ins_to_bag_one, new_ins_to_bag_two, new_ins_to_bag_three))

                new_ins_to_bag = np.sign(new_ins_to_bag) * (np.sqrt(np.abs(new_ins_to_bag)))
                new_ins_to_bag = new_ins_to_bag / np.linalg.norm(new_ins_to_bag)
                single_bag_instance += new_ins_to_bag
            new_bag.append(single_bag_instance)

        return np.array(new_bag)

    def __test_single_instance(self):
        new_bag = []
        for i in range(self.test_bags.shape[0]):
            single_bag_instance = np.zeros(self.num_att * 3).astype('float64')
            print('---------------------------------------------------------------')
            print(self.test_bags[i, -1])
            bag_center_ins = np.zeros(3).astype('float32')
            for ins_to_bag in self.test_bags[i, 0][:, :-1]:
                ins_center_dis = np.zeros(3).astype('float32')
                for i_center in range(3):
                    ins_center_dis[i_center] = 1 / (np.linalg.norm(ins_to_bag - self.center_cluster[i_center]))
                ins_center_dis = self.__max_min_normalization(ins_center_dis)
                bag_center_ins += ins_center_dis
            print(bag_center_ins)
            for ins_to_bag in self.test_bags[i, 0][:, :-1]:
                ins_center_dis = np.zeros(3).astype('float32')
                for i_center in range(3):
                    ins_center_dis[i_center] = 1 / (np.linalg.norm(ins_to_bag - self.center_cluster[i_center]))
                ins_center_dis = self.__max_min_normalization(ins_center_dis)

                # if np.argmax(bag_center_ins) != 0:
                if np.argmax(bag_center_ins) == self.test_bags[i, -1]:
                    new_ins_to_bag_one = self.center_cluster[0] + (self.center_cluster[0] * ins_center_dis[0]) / \
                                         self.test_bags[i, 0].shape[0]
                    new_ins_to_bag_two = self.center_cluster[1] - (self.center_cluster[1] * ins_center_dis[1]) / \
                                         self.test_bags[i, 0].shape[0]
                    new_ins_to_bag_three = (self.center_cluster[1] + self.center_cluster[2] * ins_center_dis[2]) / 2
                else:
                    new_ins_to_bag_one = self.center_cluster[0] - (self.center_cluster[0] * ins_center_dis[0]) / \
                                         self.test_bags[i, 0].shape[0]
                    new_ins_to_bag_two = self.center_cluster[1] + (self.center_cluster[1] * ins_center_dis[1]) / \
                                         self.test_bags[i, 0].shape[0]
                    new_ins_to_bag_three = (self.center_cluster[1] + self.center_cluster[2] * ins_center_dis[2]) / 2
                # print(type(new_ins_to_bag_two))
                new_ins_to_bag = np.hstack((new_ins_to_bag_one, new_ins_to_bag_two, new_ins_to_bag_three))

                # new_ins_to_bag = np.sign(new_ins_to_bag) * (np.sqrt(np.abs(new_ins_to_bag)))
                # new_ins_to_bag = new_ins_to_bag / np.linalg.norm(new_ins_to_bag)
                single_bag_instance += new_ins_to_bag
            new_bag.append(single_bag_instance)

        return np.array(new_bag)

    def __cluster_kmeans(self):
        res_cluster = KMeans(3)
        fit_cluster = res_cluster.fit(self.ins)
        centers_cluster = fit_cluster.cluster_centers_
        return centers_cluster

    def __get_positive_instance(self):
        instance_space = []
        for i in range(self.bags.shape[0]):
            if self.bags[i, -1] == 1:
                for ins in self.bags[i, 0][:, :-1]:
                    instance_space.append(ins)
        return np.array(instance_space)

    def __max_min_normalization(self, para_vector):
        para_vector = para_vector / np.sum(para_vector)
        return para_vector


if __name__ == '__main__':
    file_path = "D:/Data/data_zero/benchmark/musk1.mat"
    mil = MILTool(file_path)
    bags = mil.bags
    instance = mil.instance_space
    # print(instance.shape)
    # print(1 == bags[0, -1])
    a = IdeaDemo001(bags).bag_to_instance
    print(a)
    # a = np.array([1, 2, 3])
    # b = np.array([1, 2, 3])
    # c = np.array([1, 2, 3])
    # print(np.hstack((a, b,c)))
