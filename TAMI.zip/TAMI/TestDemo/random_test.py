# # import numpy as np
# #
# # acc = np.array([[80.4, 77.7, 83.2, 79.9, 84.2, 84.1, 82.4, 84.2, 89.8],
# #                 [58.3, 63.9, 59.9, 63.9, 66.0, 65.5, 60.6, 57.2, 67.6],
# #                 [67.1, 69.2, 80.0, 80.5, 79.0, 85.6, 78.5, 64.6, 85.8],
# #                 [87.8, 82.0, 88.5, 87.6, 84.7, 84.7, 88.0, 87.8, 79.9],
# #                 [66.2, 60.7, 63.1, 57.1, 49.1, 49.5, 54.2, 70.2, 47.1],
# #                 [70.5, 68.9, 65.7, 70.9, 74.9, 71.4, 62.7, 68.6, 73.8],
# #                 [50.1, 83.8, 53.1, 80.6, 83.4, 85.1, 48.8, 51.3, 87.5],
# #                 [42.9, 76.6, 44.9, 69.8, 79.3, 74.8, 49.5, 47.0, 81.2],
# #                 [45.1, 66.0, 47.4, 20.4, 70.6, 63.8, 52.0, 47.0, 69.7],
# #                 [52.1, 76.1, 54.4, 71.1, 76.9, 75.3, 46.4, 48.3, 74.7],
# #                 [60.7, 73.2, 52.0, 48.4, 84.4, 81.0, 52.6, 47.6, 82.6],
# #                 [44.3, 55.0, 44.4, 29.6, 69.7, 66.7, 45.1, 51.6, 67.9],
# #                 [50.4, 76.8, 48.6, 21.8, 87.0, 80.4, 53.4, 50.6, 82.6],
# #                 [46.2, 82.2, 45.8, 75.2, 87.5, 88.1, 44.7, 47.0, 88.6],
# #                 [51.9, 76.8, 47.6, 68.8, 76.5, 79.8, 50.0, 47.8, 87.8],
# #                 [52.4, 81.2, 57.2, 61.5, 83.5, 80.5, 54.3, 48.9, 88.1],
# #                 [40.0, 53.2, 40.5, 46.4, 35.9, 44.0, 36.6, 38.6, 47.1],
# #                 [44.2, 44.0, 45.7, 56.6, 31.4, 43.0, 38.9, 39.9, 48.3],
# #                 [53.9, 48.4, 43.2, 51.6, 32.5, 48.1, 43.0, 38.6, 43.6],
# #                 [86.2, 87.2, 87.9, 87.5, 87.5, 89.4, 88.7, 77.3, 90.1],
# #                 [88.1, 88.1, 88.0, 86.9, 87.1, 89.5, 87.5, 80.0, 89.3],
# #                 [89.3, 87.0, 88.5, 88.3, 87.5, 89.8, 90.8, 75.4, 90.3],
# #                 [57.3, 36.9, 56.5, 55.5, 59.4, 70.8, 52.1, 60.9, 72.1],
# #                 [56.0, 26.2, 54.7, 51.8, 67.1, 71.2, 54.6, 61.8, 76.0],
# #                 [57.5, 27.9, 57.2, 49.2, 68.4, 74.3, 53.5, 54.5, 76.3]])
# # #
# # # a = [[92.2, 69.6, 91.5, 92.9, 93.4],
# # #      [96.0, 66.7, 95.8, 96.8, 97.1],
# # #      [95.6, 71.7, 94.9, 95.8, 96.6]]
# # # std_a = [[0.01, 0.04, 0.01, 0.01, 0.04],
# # #          [0.00, 0.04, 0.00, 0.00, 0.01],
# # #          [0.01, 0.04, 0.01, 0.01, 0.05]]
# #
# # ave = np.mean(acc, axis=0)
# #
# # sta = [[0.13, 0.12, 2.26, 0.08, 0.10, 0.14, 2.01, 4.23, 1.07],
# #        [0.27, 0.46, 1.84, 0.46, 0.12, 0.18, 2.24, 3.34, 1.77],
# #        [0.28, 0.14, 1.86, 0.08, 0.07, 0.12, 2.92, 3.15, 0.48],
# #        [0.12, 0.08, 1.07, 1.10, 0.05, 0.09, 0.98, 1.43, 1.17],
# #        [0.43, 0.55, 10.93, 9.04, 0.56, 0.86, 4.10, 2.24, 10.0],
# #        [0.04, 0.05, 0.74, 0.02, 0.04, 0.05, 1.23, 0.87, 0.33],
# #        [0.70, 0.06, 0.45, 0.15, 0.15, 0.17, 0.67, 5.09, 1.89],
# #        [0.66, 0.13, 0.61, 0.08, 0.13, 0.16, 0.53, 0.42, 3.28],
# #        [0.42, 0.22, 0.41, 0.39, 0.13, 0.34, 0.24, 0.45, 2.93],
# #        [0.57, 0.18, 0.52, 0.15, 0.11, 0.19, 0.59, 0.49, 3.01],
# #        [0.50, 0.12, 0.42, 0.25, 0.12, 0.16, 0.69, 0.64, 2.23],
# #        [0.33, 0.19, 0.58, 0.24, 0.29, 0.36, 0.53, 0.47, 2.04],
# #        [0.51, 0.12, 0.44, 0.53, 0.11, 0.15, 0.51, 0.52, 1.74],
# #        [0.45, 0.09, 0.33, 0.17, 0.16, 0.13, 0.43, 0.40, 1.43],
# #        [0.47, 0.07, 0.25, 0.12, 0.12, 0.19, 0.46, 0.48, 0.72],
# #        [0.48, 0.05, 0.30, 0.17, 0.08, 0.18, 0.43, 0.52, 1.66],
# #        [0.04, 0.05, 0.06, 0.38, 0.04, 0.24, 0.08, 0.97, 4.67],
# #        [0.02, 0.06, 0.07, 0.49, 0.02, 0.05, 0.07, 0.84, 6.07],
# #        [0.06, 0.07, 0.04, 0.34, 0.01, 0.03, 0.07, 0.90, 6.62],
# #        [0.00, 0.05, 0.01, 0.05, 0.04, 0.08, 0.00, 0.85, 0.58],
# #        [0.00, 0.03, 0.00, 0.05, 0.05, 0.06, 0.00, 0.02, 0.73],
# #        [0.00, 0.09, 0.01, 0.04, 0.04, 0.08, 0.01, 0.54, 0.79],
# #        [0.01, 0.48, 0.01, 0.48, 0.34, 0.26, 0.05, 0.63, 2.86],
# #        [0.05, 0.40, 0.05, 0.64, 0.36, 0.31, 0.02, 0.82, 2.61],
# #        [0.03, 0.54, 0.03, 0.30, 0.46, 0.13, 0.04, 0.73, 2.83]]
# # ave_std = np.mean(sta, axis=0)
# # # for i in range(9):
# # #     print("&$%.1lf_{\pm%.2lf}$\t\t" % (ave[i], ave_std[i]), end="")
# # # import numpy as np
# # #
# # # a = np.array([2.0, 1.0, 2.0, 1.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0])
# # # b = np.array([88, 87, 86, 92, 72, 89, 87, 78, 80, 95, 81, 82, 95, 90, 84])
# # # c = a * b
# # # print(np.sum(a))
# # # print(c)
# # # print(np.sum(c) / np.sum(a) * 0.25)
# import random
# from fractions import Fraction
#
#
# class random_test:
#     def __init__(self):
#         self.random_num = self.random_filter(1000)
#
#     # 返回类型是tuple，因为list不可哈希
#     def random_pick(self, some_list, probabilities):  # 按照规则生成二元组
#         result = ()  # 二元组结果
#         for i in range(0, 2):  # 构造二元组
#             cumulative_probability = 0.0  # 初始化概率值
#             x = random.uniform(0, 1)  # 随机生成一个0到1之间的值
#             for item, item_probability in zip(some_list, probabilities):
#                 cumulative_probability += item_probability  # 累加规则中的概率值
#                 if x < cumulative_probability:  # 如果x在0到1/3内，添加1；如果在1/3到1，添加0
#                     result += (item,)
#                     break
#         return result
#
#     def test(self):
#         zero = 0
#         one = 0
#         for i in range(100):
#             x = random.uniform(0, 1)
#             if x < 0.2:
#                 zero += zero + 1
#             else:
#                 one += one + 1
#         return zero, one
#
#     def random_filter(self, num):
#         a = [1, 0]
#         b = [Fraction(1, 3), Fraction(2, 3)]  # 概率分布
#         all_collection = [(0, 1), (1, 0), (0, 0), (1, 1)]  # 所有结果
#         result_collection = [(0, 1), (1, 0)]  # 我们需要的结果
#         all, re, count = dict(zip(all_collection, [0] * 4)), dict(
#             zip(result_collection, [0] * 2)), 0  # 前两个变量为所有结果和需要结果的dict，最后一个count变量为需要结果的计数
#         for x in range(num):
#             result = self.random_pick(a, b)
#             print(result)
#             all[result] += 1
#             if result in result_collection:
#                 count += 1
#                 re[result] += 1
#         for v, value in re.items():
#             re[v] = float(value) / count
#         for v, value in all.items():
#             all[v] = float(value) / num
#         # 返回所有结果和需要结果，所有结果all 用来验证四种情况是不是2/9 2/9 4/9 1/9分布，需要结果re 用来验证是不是得到了最后的1/2的0和1/2的1的生成器
#         return all[(0, 0)]
#         # for item in random_filter(100):  # 做10万次生成试验
#
#     #     item
#
#
# if __name__ == '__main__':
#     a = random_test().random_num
#     print(a)
# -*- coding: utf-8 -*-
import math
import random

import matplotlib.pyplot as plt
import numpy as np

from MILFrame.MILTool import MILTool


class Canopy:
    def __init__(self, dataset):
        self.dataset = dataset
        self.t1 = 0
        self.t2 = 0

    # 设置初始阈值
    def setThreshold(self, t1, t2):
        if t1 > t2:
            self.t1 = t1
            self.t2 = t2
        else:
            print('t1 needs to be larger than t2!')

    # 使用欧式距离进行距离的计算
    def euclideanDistance(self, vec1, vec2):
        return math.sqrt(((vec1 - vec2) ** 2).sum())

    # 根据当前dataset的长度随机选择一个下标
    def getRandIndex(self):
        return random.randint(0, len(self.dataset) - 1)

    def clustering(self):
        if self.t1 == 0:
            print('Please set the threshold.')
        else:
            canopies = []  # 用于存放最终归类结果
            while len(self.dataset) != 0:
                rand_index = self.getRandIndex()
                current_center = self.dataset[rand_index]  # 随机获取一个中心点，定为P点
                current_center_list = []  # 初始化P点的canopy类容器
                delete_list = []  # 初始化P点的删除容器
                self.dataset = np.delete(
                    self.dataset, rand_index, 0)  # 删除随机选择的中心点P
                for datum_j in range(len(self.dataset)):
                    datum = self.dataset[datum_j]
                    distance = self.euclideanDistance(
                        current_center, datum)  # 计算选取的中心点P到每个点之间的距离
                    if distance < self.t1:
                        # 若距离小于t1，则将点归入P点的canopy类
                        current_center_list.append(datum)
                    if distance < self.t2:
                        delete_list.append(datum_j)  # 若小于t2则归入删除容器
                # 根据删除容器的下标，将元素从数据集中删除
                self.dataset = np.delete(self.dataset, delete_list, 0)
                canopies.append((current_center, current_center_list))
        return canopies


def showCanopy(canopies, dataset, t1, t2):
    fig = plt.figure()
    sc = fig.add_subplot(111)
    colors = ['brown', 'green', 'blue', 'y', 'r', 'tan', 'dodgerblue', 'deeppink', 'orangered', 'peru', 'blue', 'y',
              'r',
              'gold', 'dimgray', 'darkorange', 'peru', 'blue', 'y', 'r', 'cyan', 'tan', 'orchid', 'peru', 'blue', 'y',
              'r', 'sienna']
    markers = ['*', 'h', 'H', '+', 'o', '1', '2', '3', ',', 'v', 'H', '+', '1', '2', '^',
               '&lt;', '&gt;', '.', '4', 'H', '+', '1', '2', 's', 'p', 'x', 'D', 'd', '|', '_']
    for i in range(len(canopies)):
        canopy = canopies[i]
        center = canopy[0]
        components = canopy[1]
        sc.plot(center[0], center[1], marker=markers[i],
                color=colors[i], markersize=10)
        t1_circle = plt.Circle(
            xy=(center[0], center[1]), radius=t1, color='dodgerblue', fill=False)
        t2_circle = plt.Circle(
            xy=(center[0], center[1]), radius=t2, color='skyblue', alpha=0.2)
        sc.add_artist(t1_circle)
        sc.add_artist(t2_circle)
        for component in components:
            sc.plot(component[0], component[1],
                    marker=markers[i], color=colors[i], markersize=1.5)
    maxvalue = np.amax(dataset)
    minvalue = np.amin(dataset)
    plt.xlim(minvalue - t1, maxvalue + t1)
    plt.ylim(minvalue - t1, maxvalue + t1)
    plt.show()


if __name__ == "__main__":
    # dataset = np.random.rand(500, 3)  # 随机生成500个二维[0,1)平面点
    file_path = "D:/Data/data_zero/benchmark/fox.mat"
    mil = MILTool(file_path)
    bags = mil.bags
    dataset = mil.instance_space
    dis = np.sqrt(np.sum(np.square(dataset[1] - dataset[0])))
    t1 = 0.6 * dis
    t2 = 0.4 * dis
    gc = Canopy(dataset)
    gc.setThreshold(t1, t2)
    canopies = gc.clustering()
    # print(canopies)
    print('Get %s initial centers.' % len(canopies))
# showCanopy(canopies, dataset, t1, t2)
