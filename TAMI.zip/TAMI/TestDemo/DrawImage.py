# @Time : 1021/5/10 19:35
# @Author: ZWX
# @Email: 935721546@qq.com
# @File : DrawImage.py
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns


def MyHeatMap():
    sns.set(font_scale=1)
    fox_acc_svm = np.array([[61.3, 62.0, 64.3, 60.6, 59.8, 64.5],
                            [61.9, 60.3, 63.2, 61.4, 61.5, 64.4],
                            [60.7, 59.3, 64.9, 60.5, 60.5, 63.2],
                            [60.7, 61.0, 63.0, 60.8, 61.3, 64.2],
                            [60.3, 60.7, 65.5, 61.5, 60.9, 63.9]])
    fox_acc_knn = np.array([[59.7, 61.4, 60.4, 60.4, 60.9, 59.5],
                            [61.2, 58.4, 60.1, 61.6, 59.6, 58.8],
                            [59.8, 60.2, 59.0, 62.0, 59.6, 60.9],
                            [61.0, 58.4, 61.3, 61.2, 60.6, 60.7],
                            [61.6, 59.6, 60.6, 59.6, 61.3, 60.0]])

    fox_acc_DTree = np.array([[56.8, 56.2, 56.2, 54.8, 55.6, 53.6],
                              [56.4, 55.9, 55.8, 56.2, 55.6, 55.2],
                              [55.6, 56.6, 53.8, 58.0, 56.6, 56.1],
                              [54.8, 56.9, 54.3, 54.8, 56.8, 55.1],
                              [55.1, 57.4, 54.2, 56.2, 58.8, 54.4]])

    elephant_acc_svm = np.array([[89.6, 88.7, 88.5, 89.8, 88.8, 87.9],
                                 [89.8, 88.1, 87.2, 89.3, 87.6, 88.0],
                                 [89.5, 87.2, 87.3, 90.4, 86.5, 87.9],
                                 [90.1, 86.8, 88.0, 89.5, 86.4, 88.1],
                                 [89.1, 86.3, 87.9, 90.2, 86.0, 87.8]])

    elephant_acc_knn = np.array([[85.3, 84.7, 82.9, 84.8, 85.0, 83.5],
                                 [83.8, 84.4, 83.0, 84.7, 84.4, 83.3],
                                 [84.4, 84.9, 83.5, 84.6, 85.5, 83.1],
                                 [84.1, 84.4, 81.9, 84.6, 83.9, 83.3],
                                 [84.1, 84.1, 83.1, 84.6, 84.5, 82.6]])

    elephant_acc_DTree = np.array([[74.6, 74.8, 75.3, 75.9, 74.5, 75.3],
                                   [73.8, 74.9, 75.5, 74.9, 73.7, 74.7],
                                   [76.3, 75.0, 75.1, 73.9, 74.2, 75.6],
                                   [75.9, 76.9, 75.6, 74.9, 74.1, 73.3],
                                   [76.6, 73.8, 72.8, 74.2, 72.7, 73.7]])

    tiger_acc_knn = np.array([[68.5, 69.1, 69.4, 68.9, 69.9, 68.8],
                              [69.3, 68.3, 69.0, 68.5, 68.0, 68.6],
                              [69.4, 69.7, 70.2, 69.5, 69.8, 69.6],
                              [69.2, 69.3, 69.4, 69.1, 69.2, 69.2],
                              [69.9, 70.0, 68.8, 68.5, 69.3, 70.0]])

    tiger_acc_DTree = np.array([[71.0, 71.5, 72.7, 72.1, 70.8, 72.1],
                                [71.5, 73.1, 71.5, 73.2, 72.4, 70.4],
                                [72.0, 71.0, 69.9, 71.4, 71.9, 72.2],
                                [72.0, 73.0, 72.1, 71.8, 70.9, 72.3],
                                [73.0, 74.5, 70.0, 72.5, 70.8, 73.4]])

    tiger_acc_svm = np.array([[87.5, 88.0, 87.5, 87.3, 88.1, 87.3],
                              [87.5, 86.5, 87.3, 87.9, 86.7, 87.0],
                              [87.2, 87.3, 87.0, 86.7, 87.8, 87.7],
                              [87.8, 87.5, 87.0, 87.0, 87.6, 87.3],
                              [87.3, 87.7, 86.9, 87.1, 87.5, 86.7]])
    Num = ['1', '2', '3', '4', '5']
    Model = ['S-G', 'S-P', 'S-N', 'C-G', 'C-P', 'C-N']
    # cmaps = [plt.cm.jet, plt.cm.gray, plt.cm.cool, plt.cm.hot]

    f, ax = plt.subplots(figsize=(24, 24), nrows=3, ncols=3)
    ax[0][0].set_title('Data:fox \n Classifier: Knn', fontsize=10)
    ax[0][1].set_title('Data:fox \n Classifier: DTree', fontsize=10)
    ax[0][2].set_title('Data:fox \n Classifier: SVM', fontsize=10)

    ax[1][0].set_title('Data:elephant \n Classifier: Knn', fontsize=10)
    ax[1][1].set_title('Data:elephant \n Classifier: DTree', fontsize=10)
    ax[1][2].set_title('Data:elephant \n Classifier: SVM', fontsize=10)

    ax[2][0].set_title('Data:alt_atheism \n Classifier: Knn', fontsize=10)
    ax[2][1].set_title('Data:alt_atheism \n Classifier: DTree', fontsize=10)
    ax[2][2].set_title('Data:alt_atheism \n Classifier: SVM', fontsize=10)

    sns.heatmap(fox_acc_knn, annot=True, fmt='.1f', ax=ax[0][0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(fox_acc_DTree, annot=True, fmt='.1f', ax=ax[0][1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(fox_acc_svm, annot=True, fmt='.1f', ax=ax[0][2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})

    sns.heatmap(elephant_acc_knn, annot=True, fmt='.1f', ax=ax[1][0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(elephant_acc_DTree, annot=True, fmt='.1f', ax=ax[1][1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(elephant_acc_svm, annot=True, fmt='.1f', ax=ax[1][2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(tiger_acc_knn, annot=True, fmt='.1f', ax=ax[2][0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(tiger_acc_DTree, annot=True, fmt='.1f', ax=ax[2][1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(tiger_acc_svm, annot=True, fmt='.1f', ax=ax[2][2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    # print(f)
    ax[2][0].set_xlabel('Model', fontsize=10)
    ax[2][1].set_xlabel('Model', fontsize=10)
    ax[2][2].set_xlabel('Model', fontsize=10)
    # ax[0].set_ylabel('Number of discriminative  instances')
    # ax[1].set_ylabel('Number of discriminative  instances')
    # ax[2].set_ylabel('Number of discriminative  instances')

    plt.savefig("D:/HeatMap_Three_data.pdf")
    plt.show()


def FoxELephant():
    sns.set(font_scale=1.8)
    fox_acc_svm = np.array([[61.3, 62.0, 64.3, 60.6, 59.8, 64.5],
                            [61.9, 60.3, 63.2, 61.4, 61.5, 64.4],
                            [60.7, 59.3, 64.9, 60.5, 60.5, 63.2],
                            [60.7, 61.0, 63.0, 60.8, 61.3, 64.2],
                            [60.3, 60.7, 65.5, 61.5, 60.9, 63.9]])
    fox_acc_knn = np.array([[59.7, 61.4, 60.4, 60.4, 60.9, 59.5],
                            [61.2, 58.4, 60.1, 61.6, 59.6, 58.8],
                            [59.8, 60.2, 59.0, 62.0, 59.6, 60.9],
                            [61.0, 58.4, 61.3, 61.2, 60.6, 60.7],
                            [61.6, 59.6, 60.6, 59.6, 61.3, 60.0]])

    fox_acc_DTree = np.array([[56.8, 56.2, 56.2, 54.8, 55.6, 53.6],
                              [56.4, 55.9, 55.8, 56.2, 55.6, 55.2],
                              [55.6, 56.6, 53.8, 58.0, 56.6, 56.1],
                              [54.8, 56.9, 54.3, 54.8, 56.8, 55.1],
                              [55.1, 57.4, 54.2, 56.2, 58.8, 54.4]])

    elephant_acc_svm = np.array([[89.6, 88.7, 88.5, 89.8, 88.8, 87.9],
                                 [89.8, 88.1, 87.2, 89.3, 87.6, 88.0],
                                 [89.5, 87.2, 87.3, 90.4, 86.5, 87.9],
                                 [90.1, 86.8, 88.0, 89.5, 86.4, 88.1],
                                 [89.1, 86.3, 87.9, 90.2, 86.0, 87.8]])

    elephant_acc_knn = np.array([[85.3, 84.7, 82.9, 84.8, 85.0, 83.5],
                                 [83.8, 84.4, 83.0, 84.7, 84.4, 83.3],
                                 [84.4, 84.9, 83.5, 84.6, 85.5, 83.1],
                                 [84.1, 84.4, 81.9, 84.6, 83.9, 83.3],
                                 [84.1, 84.1, 83.1, 84.6, 84.5, 82.6]])

    elephant_acc_DTree = np.array([[74.6, 74.8, 75.3, 75.9, 74.5, 75.3],
                                   [73.8, 74.9, 75.5, 74.9, 73.7, 74.7],
                                   [76.3, 75.0, 75.1, 73.9, 74.2, 75.6],
                                   [75.9, 76.9, 75.6, 74.9, 74.1, 73.3],
                                   [76.6, 73.8, 72.8, 74.2, 72.7, 73.7]])

    # tiger_acc_svm = np.array([[83.0, 83.4, 85.4, 83.6, 83.1, 85.1],
    #                           [83.9, 84.0, 85.1, 83.3, 83.6, 85.0],
    #                           [83.6, 83.7, 85.3, 83.0, 84.1, 85.6],
    #                           [83.5, 84.2, 85.4, 83.1, 83.9, 85.1],
    #                           [83.8, 84.0, 85.4, 82.7, 83.6, 85.7]])
    # tiger_acc_knn = np.array([[80.1, 80.6, 78.7, 80.0, 80.3, 78.0],
    #                           [79.9, 79.5, 77.8, 80.2, 79.8, 78.3],
    #                           [79.9, 79.2, 79.0, 80.2, 80.3, 79.1],
    #                           [80.0, 78.3, 78.5, 80.2, 79.8, 78.8],
    #                           [79.9, 78.5, 78.6, 80.2, 80.7, 78.6]])
    #
    # tiger_acc_DTree = np.array([[70.2, 70.1, 73.4, 70.8, 71.4, 74.4],
    #                             [71.1, 70.3, 74.2, 70.0, 70.0, 72.1],
    #                             [68.2, 70.8, 74.7, 70.7, 70.9, 75.5],
    #                             [71.5, 70.8, 73.8, 70.7, 73.0, 74.7],
    #                             [71.3, 72.2, 73.8, 71.1, 74.7, 72.8]])
    Num = ['1', '2', '3', '4', '5']
    Model = ['S-G', 'S-P', 'S-N', 'C-G', 'C-P', 'C-N']
    # cmaps = [plt.cm.jet, plt.cm.gray, plt.cm.cool, plt.cm.hot]

    f, ax = plt.subplots(figsize=(24, 24), nrows=2, ncols=3)
    ax[0][0].set_title('Data:fox \n Classifier: Knn', fontsize=10)
    ax[0][1].set_title('Data:fox \n Classifier: DTree', fontsize=10)
    ax[0][2].set_title('Data:fox \n Classifier: SVM', fontsize=10)

    ax[1][0].set_title('Data:elephant \n Classifier: Knn', fontsize=10)
    ax[1][1].set_title('Data:elephant \n Classifier: DTree', fontsize=10)
    ax[1][2].set_title('Data:elephant \n Classifier: SVM', fontsize=10)

    # ax[2][0].set_title('Data:tiger \n Classifier: Knn', fontsize=10)
    # ax[2][1].set_title('Data:tiger \n Classifier: DTree', fontsize=10)
    # ax[2][2].set_title('Data:tiger \n Classifier: SVM', fontsize=10)

    sns.heatmap(fox_acc_knn, annot=True, fmt='.1f', ax=ax[0][0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(fox_acc_DTree, annot=True, fmt='.1f', ax=ax[0][1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(fox_acc_svm, annot=True, fmt='.1f', ax=ax[0][2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})

    sns.heatmap(elephant_acc_knn, annot=True, fmt='.1f', ax=ax[1][0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(elephant_acc_DTree, annot=True, fmt='.1f', ax=ax[1][1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(elephant_acc_svm, annot=True, fmt='.1f', ax=ax[1][2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    # sns.heatmap(tiger_acc_knn, annot=True, fmt='.1f', ax=ax[2][0], cmap='rainbow', yticklabels=Num,
    #             xticklabels=Model, annot_kws={"fontsize": 10})
    # sns.heatmap(tiger_acc_DTree, annot=True, fmt='.1f', ax=ax[2][1], cmap='rainbow', yticklabels=Num,
    #             xticklabels=Model, annot_kws={"fontsize": 10})
    # sns.heatmap(tiger_acc_svm, annot=True, fmt='.1f', ax=ax[2][2], cmap='rainbow', yticklabels=Num,
    #             xticklabels=Model, annot_kws={"fontsize": 10})
    # print(f)
    # ax[2][0].set_xlabel('Model', fontsize=10)
    # ax[2][1].set_xlabel('Model', fontsize=10)
    # ax[2][2].set_xlabel('Model', fontsize=10)
    # ax[0].set_ylabel('Number of discriminative  instances')
    # ax[1].set_ylabel('Number of discriminative  instances')
    # ax[2].set_ylabel('Number of discriminative  instances')

    plt.savefig("D:/HeatMap_Two_data.pdf")
    plt.show()


def ElephantImage():
    sns.set(font_scale=1.5)
    elephant_acc_svm = np.array([[89.6, 88.7, 88.5, 89.8, 88.8, 87.9],
                                 [89.8, 88.1, 87.2, 89.3, 87.6, 88.0],
                                 [89.5, 87.2, 87.3, 90.4, 86.5, 87.9],
                                 [90.1, 86.8, 88.0, 89.5, 86.4, 88.1],
                                 [89.1, 86.3, 87.9, 90.2, 86.0, 87.8]])

    elephant_acc_knn = np.array([[85.3, 84.7, 82.9, 84.8, 85.0, 83.5],
                                 [83.8, 84.4, 83.0, 84.7, 84.4, 83.3],
                                 [84.4, 84.9, 83.5, 84.6, 85.5, 83.1],
                                 [84.1, 84.4, 81.9, 84.6, 83.9, 83.3],
                                 [84.1, 84.1, 83.1, 84.6, 84.5, 82.6]])

    elephant_acc_DTree = np.array([[74.6, 74.8, 75.3, 75.9, 74.5, 75.3],
                                   [73.8, 74.9, 75.5, 74.9, 73.7, 74.7],
                                   [76.3, 75.0, 75.1, 73.9, 74.2, 75.6],
                                   [75.9, 76.9, 75.6, 74.9, 74.1, 73.3],
                                   [76.6, 73.8, 72.8, 74.2, 72.7, 73.7]])

    Num = ['1', '2', '3', '4', '5']
    Model = ['SG', 'SP', 'SN', 'CG', 'CP', 'CN']
    # cmaps = [plt.cm.jet, plt.cm.gray, plt.cm.cool, plt.cm.hot]

    f, ax = plt.subplots(figsize=(24, 8), nrows=1, ncols=3)

    ax[0].set_title('Data:elephant \n Classifier: Knn', fontsize=10)
    ax[1].set_title('Data:elephant \n Classifier: DTree', fontsize=10)
    ax[2].set_title('Data:elephant \n Classifier: SVM', fontsize=10)

    sns.heatmap(elephant_acc_knn, annot=True, fmt='.1f', ax=ax[0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(elephant_acc_DTree, annot=True, fmt='.1f', ax=ax[1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})
    sns.heatmap(elephant_acc_svm, annot=True, fmt='.1f', ax=ax[2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 10})

    # print(f)
    # ax[2][0].set_xlabel('Model', fontsize=10)
    # ax[2][1].set_xlabel('Model', fontsize=10)
    # ax[2][2].set_xlabel('Model', fontsize=10)
    ax[0][0].set_ylabel('Number of discriminative  instances')
    # ax[1].set_ylabel('Number of discriminative  instances')
    # ax[2].set_ylabel('Number of discriminative  instances')

    plt.savefig("D:/HeatMap_Elephant_data.pdf")
    plt.show()


def Alt_Image():
    sns.set(font_scale=2)
    # elephant_acc_knn = np.array([[68.5, 69.1, 69.4, 68.9, 69.9, 68.8],
    #                              [69.3, 68.3, 69.0, 68.5, 68.0, 68.6],
    #                              [69.4, 69.7, 70.2, 69.5, 69.8, 69.6],
    #                              [69.2, 69.3, 69.4, 69.1, 69.2, 69.2],
    #                              [69.9, 70.0, 68.8, 68.5, 69.3, 70.0]])
    #
    # elephant_acc_DTree = np.array([[71.0, 71.5, 72.7, 72.1, 70.8, 72.1],
    #                                [71.5, 73.1, 71.5, 73.2, 72.4, 70.4],
    #                                [72.0, 71.0, 69.9, 71.4, 71.9, 72.2],
    #                                [72.0, 73.0, 72.1, 71.8, 70.9, 72.3],
    #                                [73.0, 74.5, 70.0, 72.5, 70.8, 73.4]])
    #
    # elephant_acc_svm = np.array([[87.5, 88.0, 87.5, 87.3, 88.1, 87.3],
    #                              [87.5, 86.5, 87.3, 87.9, 86.7, 87.0],
    #                              [87.2, 87.3, 87.0, 86.7, 87.8, 87.7],
    #                              [87.8, 87.5, 87.0, 87.0, 87.6, 87.3],
    #                              [87.3, 87.7, 86.9, 87.1, 87.5, 86.7]])

    elephant_acc_svm = np.array([[89.6, 88.7, 88.5, 89.8, 88.8, 87.9],
                                 [89.8, 88.1, 87.2, 89.3, 87.6, 88.0],
                                 [89.5, 87.2, 87.3, 90.4, 86.5, 87.9],
                                 [90.1, 86.8, 88.0, 89.5, 86.4, 88.1],
                                 [89.1, 86.3, 87.9, 90.2, 86.0, 87.8]])

    elephant_acc_knn = np.array([[85.3, 84.7, 82.9, 84.8, 85.0, 83.5],
                                 [83.8, 84.4, 83.0, 84.7, 84.4, 83.3],
                                 [84.4, 84.9, 83.5, 84.6, 85.5, 83.1],
                                 [84.1, 84.4, 81.9, 84.6, 83.9, 83.3],
                                 [84.1, 84.1, 83.1, 84.6, 84.5, 82.6]])

    elephant_acc_DTree = np.array([[74.6, 74.8, 75.3, 75.9, 74.5, 75.3],
                                   [73.8, 74.9, 75.5, 74.9, 73.7, 74.7],
                                   [76.3, 75.0, 75.1, 73.9, 74.2, 75.6],
                                   [75.9, 76.9, 75.6, 74.9, 74.1, 73.3],
                                   [76.6, 73.8, 72.8, 74.2, 72.7, 73.7]])


    Num = ['1', '2', '3', '4', '5']
    Model = ['S-G', 'S-P', 'S-N', 'C-G', 'C-P', 'C-N']
    # cmaps = [plt.cm.jet, plt.cm.gray, plt.cm.cool, plt.cm.hot]

    f, ax = plt.subplots(figsize=(24, 8), nrows=1, ncols=3)

    ax[0].set_title('Classifier: Knn', fontsize=20)
    ax[1].set_title('Classifier: DTree', fontsize=20)
    ax[2].set_title('Classifier: SVM', fontsize=20)

    sns.heatmap(elephant_acc_knn, annot=True, fmt='.1f', ax=ax[0], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 20})
    sns.heatmap(elephant_acc_DTree, annot=True, fmt='.1f', ax=ax[1], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 20})
    sns.heatmap(elephant_acc_svm, annot=True, fmt='.1f', ax=ax[2], cmap='rainbow', yticklabels=Num,
                xticklabels=Model, annot_kws={"fontsize": 20})

    # print(f)
    # ax[2][0].set_xlabel('Model', fontsize=10)
    # ax[2][1].set_xlabel('Model', fontsize=10)
    # ax[2][2].set_xlabel('Model', fontsize=10)
    # ax[0][0].set_ylabel('Number of discriminative  instances')
    # ax[1].set_ylabel('Number of discriminative  instances')
    # ax[2].set_ylabel('Number of discriminative  instances')

    plt.savefig("D:/HeatMap_Elephant_data.pdf")
    plt.show()

if __name__ == '__main__':
    # FoxELephant()
    # MT()
    # MyHeatMap()
    Alt_Image()
    # ElephantImage()